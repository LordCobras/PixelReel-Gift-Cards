<?php
namespace Opencart\Admin\Controller\Extension\PixelgiftClean\Module;

class Giftcard extends \Opencart\System\Engine\Controller {
    public function index(): void {
        $this->load->language('extension/pixelgift_clean/module/giftcard');

        $this->document->setTitle($this->language->get('heading_title'));

        $token = 'user_token=' . $this->session->data['user_token'];

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', $token)
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', $token . '&type=module')
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/pixelgift_clean/module/giftcard', $token)
        ];

        $data['save'] = $this->url->link('extension/pixelgift_clean/module/giftcard.save', $token);
        $data['back'] = $this->url->link('marketplace/extension', $token . '&type=module');

        $data['module_giftcard_status'] = (int)$this->config->get('module_giftcard_status');
        $data['module_giftcard_values'] = $this->config->get('module_giftcard_values') ?: '10,25,50,100,200';

        $this->load->model('extension/pixelgift_clean/module/giftcard');
        $data['issued_cards'] = $this->model_extension_pixelgift_clean_module_giftcard->getCards();
        $data['issue_url'] = $this->url->link('extension/pixelgift_clean/module/giftcard.issue', $token);
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/pixelgift_clean/module/giftcard', $data));
    }

    public function save(): void {
        $this->load->language('extension/pixelgift_clean/module/giftcard');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/pixelgift_clean/module/giftcard')) {
            $json['error'] = $this->language->get('error_permission');
        }

        $values = array_filter(array_map('trim', explode(',', (string)($this->request->post['module_giftcard_values'] ?? ''))), 'strlen');

        if (!$values) {
            $json['error'] = $this->language->get('error_values');
        }

        foreach ($values as $value) {
            if (!is_numeric($value) || (float)$value <= 0) {
                $json['error'] = $this->language->get('error_values');
                break;
            }
        }

        if (!$json) {
            $this->load->model('setting/setting');

            $this->model_setting_setting->editSetting('module_giftcard', [
                'module_giftcard_status' => (int)($this->request->post['module_giftcard_status'] ?? 0),
                'module_giftcard_values' => implode(',', $values)
            ]);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }


    public function issue(): void {
        $json = [];
        if (!$this->user->hasPermission('modify', 'extension/pixelgift_clean/module/giftcard')) {
            $json['error'] = 'Permission denied';
        } else {
            $amount = (float)($this->request->post['amount'] ?? 0);
            $allowed = array_map('floatval', explode(',', (string)$this->config->get('module_giftcard_values')));
            if ($amount <= 0 || !in_array($amount, $allowed, true)) {
                $json['error'] = 'Choose an allowed denomination';
            } else {
                $this->load->model('extension/pixelgift_clean/module/giftcard');
                try {
                    $json['code'] = $this->model_extension_pixelgift_clean_module_giftcard->issue($amount);
                    $json['success'] = 'Code created (inactive for checkout; management only)';
                } catch (\Throwable $e) {
                    $json['error'] = 'Could not create code; check module installation and database permissions';
                }
            }
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('extension/pixelgift_clean/module/giftcard');
        $this->model_extension_pixelgift_clean_module_giftcard->install();
        if ($this->user->hasPermission('modify', 'extension/module')) {
            $this->load->model('setting/setting');

            $this->model_setting_setting->editSetting('module_giftcard', [
                'module_giftcard_status' => 0,
                'module_giftcard_values' => '10,25,50,100,200'
            ]);
        }
    }

    public function uninstall(): void {
        if ($this->user->hasPermission('modify', 'extension/module')) {
            $this->load->model('setting/setting');

            $this->model_setting_setting->deleteSetting('module_giftcard');
        }
    }
}
