<?php
namespace Opencart\Admin\Model\Extension\PixelgiftClean\Module;
class Giftcard extends \Opencart\System\Engine\Model {
    public function install(): void {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "pixelgift_card` (
            `card_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `code_hash` CHAR(64) NOT NULL,
            `code_last4` CHAR(4) NOT NULL,
            `amount` DECIMAL(15,4) NOT NULL,
            `currency` CHAR(3) NOT NULL DEFAULT 'EUR',
            `status` VARCHAR(20) NOT NULL DEFAULT 'draft',
            `date_added` DATETIME NOT NULL,
            PRIMARY KEY (`card_id`),
            UNIQUE KEY `code_hash` (`code_hash`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    public function issue(float $amount): string {
        $this->install();
        for ($attempt=0; $attempt<3; $attempt++) {
            $raw = strtoupper(bin2hex(random_bytes(8)));
            $code = implode('-', str_split($raw, 4));
            $hash = hash('sha256', $code);
            try {
                $this->db->query("INSERT INTO `" . DB_PREFIX . "pixelgift_card`
                    SET `code_hash`='" . $this->db->escape($hash) . "',
                        `code_last4`='" . $this->db->escape(substr($raw, -4)) . "',
                        `amount`='" . (float)$amount . "',
                        `currency`='EUR', `status`='draft', `date_added`=NOW()");
                return $code;
            } catch (\Throwable $e) {
                if ($attempt === 2) throw $e;
            }
        }
        throw new \RuntimeException('Code generation failed');
    }
    public function getCards(): array {
        $this->install();
        return $this->db->query("SELECT `card_id`, `code_last4`, `amount`, `currency`, `status`, `date_added`
            FROM `" . DB_PREFIX . "pixelgift_card` ORDER BY `card_id` DESC LIMIT 50")->rows;
    }
}
