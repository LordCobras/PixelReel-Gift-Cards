<?php
// Heading
$_['heading_title']          = 'PixelReel Gift Cards';
$_['giftcard_heading_title'] = 'PixelReel Gift Cards';

// Text
$_['text_extension']   = 'Extensions';
$_['text_home']        = 'Home';
$_['text_edit']        = 'Gift card configuration';
$_['text_success']     = 'Success: You have modified PixelReel Gift Cards!';

// Entry
$_['entry_status']     = 'Status';
$_['entry_values']     = 'EUR denominations';

// Help
$_['help_values']      = 'Comma separated, e.g. 10,25,50,100,200';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify PixelReel Gift Cards!';
$_['error_values']     = 'Enter positive numeric values separated by commas!';
